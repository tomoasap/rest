# Notes:

- Built using Gatsby best practices
- All editable data is stored as markdown
